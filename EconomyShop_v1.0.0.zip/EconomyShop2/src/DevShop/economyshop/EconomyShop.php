<?php

declare(strict_types=1);

namespace DevShop\economyshop;

use InvalidArgumentException;
use DevShop\economyshop\button\ButtonFactory;
use DevShop\economyshop\button\ButtonIds;
use DevShop\economyshop\button\CategoryButton;
use DevShop\economyshop\category\Category;
use DevShop\economyshop\database\Database;
use DevShop\economyshop\libs\muqsit\invmenu\InvMenu;
use DevShop\economyshop\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

final class EconomyShop {

    private Database $database;
    private InvMenu $menu;

    /** @var Category[] */
    private array $categories = [];

    public function __construct(Database $database) {
        $this->database = $database;
        $this->menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $this->menu->setName(TF::BOLD . TF::GOLD . "EconomyShop");
        $this->menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $transaction): void {
            $button = ButtonFactory::fromItem($transaction->getItemClicked());
            if (!($button instanceof CategoryButton)) {
                return;
            }
            $player = $transaction->getPlayer();
            try {
                $category = $this->getCategory($button->getCategory());
            } catch (InvalidArgumentException $e) {
                $player->sendMessage(TF::RED . $e->getMessage());
                return;
            }
            if ($category->send($player)) {
                return;
            }
            $player->removeCurrentWindow();
            $player->sendMessage(TF::RED . "This category is empty.");
        }));
    }

    public function addCategory(Category $category, bool $update = true): void {
        if (isset($this->categories[$name = $category->getName()])) {
            throw new InvalidArgumentException("Category \"{$name}\" already exists.");
        }
        $this->categories[$name] = $category;
        $this->menu->getInventory()->addItem(
            ButtonFactory::get(ButtonIds::CATEGORY, $category->getName(), $category->getButton())
        );
        if ($update) {
            $this->database->addCategory($category, function(int $id) use($category): void {
                $category->init($this->database, $id);
            });
        }
    }

    public function removeCategory(string $name): void {
        $category = $this->categories[$name] ?? throw new InvalidArgumentException("Category \"{$name}\" not found.");
        unset($this->categories[$name]);

        $inventory = $this->menu->getInventory();
        $contents  = $inventory->getContents();
        foreach ($contents as $slot => $item) {
            $button = ButtonFactory::fromItem($item);
            if ($button instanceof CategoryButton && $button->getCategory() === $name) {
                unset($contents[$slot]);
            }
        }
        $inventory->setContents($contents);
        $this->database->removeCategory($category);
    }

    public function getCategory(string $name): Category {
        return $this->categories[$name] ?? throw new InvalidArgumentException("Category \"{$name}\" not found.");
    }

    /** @return Category[] */
    public function getCategories(): array {
        return $this->categories;
    }

    public function send(Player $player): void {
        $this->menu->send($player);
    }

    /**
     * Get sell price for an item.
     * Returns 50% of buy price if item exists in any category.
     * Returns null if item is not in shop at all.
     */
    public function getSellPrice(Item $item): ?float {
        foreach ($this->categories as $category) {
            foreach ($category->getPages() as $page) {
                foreach ($page->getEntries() as $entry) {
                    if ($entry->getItem()->getTypeId() === $item->getTypeId()) {
                        return $entry->getPrice() * 0.5;
                    }
                }
            }
        }
        return null;
    }
}
