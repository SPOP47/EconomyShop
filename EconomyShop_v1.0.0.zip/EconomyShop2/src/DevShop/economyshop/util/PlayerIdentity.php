<?php

declare(strict_types=1);

namespace DevShop\economyshop\util;

use pocketmine\player\Player;
use Ramsey\Uuid\UuidInterface;

final class PlayerIdentity {

    public static function fromPlayer(Player $player): self {
        return new self($player->getUniqueId(), $player->getName());
    }

    public static function fromName(string $name): self {
        // For offline balance checks - UUID is unknown, use nil UUID
        return new self(\Ramsey\Uuid\Uuid::fromString('00000000-0000-0000-0000-000000000000'), $name);
    }

    public function __construct(
        private UuidInterface $uuid,
        private string $gamertag
    ) {}

    public function getUuid(): UuidInterface {
        return $this->uuid;
    }

    public function getGamertag(): string {
        return $this->gamertag;
    }
}
