<?php

declare(strict_types=1);

namespace DevShop\economyshop;

use InvalidArgumentException;
use DevShop\economyshop\button\ButtonFactory;
use DevShop\economyshop\category\Category;
use DevShop\economyshop\category\CategoryConfig;
use DevShop\economyshop\category\CategoryEntry;
use DevShop\economyshop\database\Database;
use DevShop\economyshop\economy\EconomyManager;
use DevShop\economyshop\ui\ConfirmationUI;
use DevShop\economyshop\libs\muqsit\invmenu\InvMenuHandler;
use DevShop\economyshop\util\PlayerIdentity;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as TF;

final class Loader extends PluginBase {

    private Database $database;
    private ?ConfirmationUI $confirmation_ui;
    private EconomyShop $economy_shop;

    protected function onEnable(): void {
        $this->initVirions();

        $this->database        = new Database($this);
        $this->confirmation_ui = $this->getConfig()->getNested("confirmation-ui.enabled", false)
            ? new ConfirmationUI($this)
            : null;
        $this->economy_shop = new EconomyShop($this->database);

        ButtonFactory::init($this);
        CategoryConfig::init($this);
        EconomyManager::init($this);

        $this->database->load($this->economy_shop);

        $this->getLogger()->info(TF::GREEN . "EconomyShop v1.0.0 enabled! /shop /sell ready!");
    }

    private function initVirions(): void {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onDisable(): void {
        $this->database->close();
    }

    public function getConfirmationUi(): ?ConfirmationUI {
        return $this->confirmation_ui;
    }

    public function getEconomyShop(): EconomyShop {
        return $this->economy_shop;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TF::RED . "This command can only be used in-game.");
            return true;
        }

        switch (strtolower($command->getName())) {
            case "shop":
                $this->handleShopCommand($sender, $label, $args);
                break;
            case "sell":
                $this->handleSellCommand($sender, $args);
                break;
            case "balance":
                $this->handleBalanceCommand($sender, $args);
                break;
            case "pay":
                $this->handlePayCommand($sender, $args);
                break;
        }

        return true;
    }

    // ─── /shop ───────────────────────────────────────────────────
    private function handleShopCommand(Player $sender, string $label, array $args): void {
        if (!isset($args[0])) {
            $this->economy_shop->send($sender);
            return;
        }

        switch ($args[0]) {
            case "addcat":
            case "addcategory":
                if (!$sender->hasPermission("economyshop.command.add")) {
                    $sender->sendMessage(TF::RED . "No permission.");
                    return;
                }
                $button = $sender->getInventory()->getItemInHand();
                if ($button->isNull()) {
                    $sender->sendMessage(TF::RED . "Hold an item — it will be used as the category icon.");
                    return;
                }
                if (!isset($args[1])) {
                    $sender->sendMessage(TF::RED . "Usage: /{$label} addcategory <name>");
                    return;
                }
                $name = implode(" ", array_slice($args, 1));
                try {
                    $this->economy_shop->addCategory(new Category($name, $button));
                } catch (InvalidArgumentException $e) {
                    $sender->sendMessage(TF::RED . $e->getMessage());
                    return;
                }
                $sender->sendMessage(TF::GREEN . "Category \"" . TF::YELLOW . $name . TF::GREEN . "\" added!");
                $sender->sendMessage(TF::GRAY . "Use: /{$label} additem {$name} <price>");
                break;

            case "removecat":
            case "removecategory":
                if (!$sender->hasPermission("economyshop.command.remove")) {
                    $sender->sendMessage(TF::RED . "No permission.");
                    return;
                }
                if (!isset($args[1])) {
                    $sender->sendMessage(TF::RED . "Usage: /{$label} removecategory <name>");
                    return;
                }
                $name = implode(" ", array_slice($args, 1));
                try {
                    $this->economy_shop->removeCategory($name);
                } catch (InvalidArgumentException $e) {
                    $sender->sendMessage(TF::RED . $e->getMessage());
                    return;
                }
                $sender->sendMessage(TF::GREEN . "Category \"" . TF::YELLOW . $name . TF::GREEN . "\" removed!");
                break;

            case "additem":
                if (!$sender->hasPermission("economyshop.command.add")) {
                    $sender->sendMessage(TF::RED . "No permission.");
                    return;
                }
                if (!isset($args[1], $args[2])) {
                    $sender->sendMessage(TF::RED . "Usage: /{$label} additem <category> <price>");
                    return;
                }
                try {
                    $category = $this->economy_shop->getCategory($args[1]);
                } catch (InvalidArgumentException $e) {
                    $sender->sendMessage(TF::RED . $e->getMessage());
                    return;
                }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Hold the item you want to add.");
                    return;
                }
                $price = (float) $args[2];
                if ($price < 0.0) {
                    $sender->sendMessage(TF::RED . "Price cannot be negative.");
                    return;
                }
                $category->addEntry(new CategoryEntry($item, $price));
                $sender->sendMessage(TF::GREEN . "Added " . TF::YELLOW . $item->getName() . TF::GREEN . " to \"" . $category->getName() . "\" for " . EconomyManager::get()->formatMoney($price) . "!");
                break;

            case "removeitem":
                if (!$sender->hasPermission("economyshop.command.remove")) {
                    $sender->sendMessage(TF::RED . "No permission.");
                    return;
                }
                if (!isset($args[1])) {
                    $sender->sendMessage(TF::RED . "Usage: /{$label} removeitem <category>");
                    return;
                }
                try {
                    $category = $this->economy_shop->getCategory($args[1]);
                } catch (InvalidArgumentException $e) {
                    $sender->sendMessage(TF::RED . $e->getMessage());
                    return;
                }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Hold the item you want to remove.");
                    return;
                }
                $removed = $category->removeItem($item);
                if ($removed === 0) {
                    $sender->sendMessage(TF::RED . "Item not found in category \"" . $category->getName() . "\".");
                    return;
                }
                $sender->sendMessage(TF::GREEN . "Removed {$removed} item(s) from \"" . $category->getName() . "\"!");
                break;

            case "help":
                $sender->sendMessage(
                    TF::BOLD . TF::GOLD . "=== EconomyShop Help ===" . TF::RESET . "\n" .
                    TF::YELLOW . "/{$label}" . TF::GRAY . " - Open shop\n" .
                    TF::YELLOW . "/{$label} addcategory <n>" . TF::GRAY . " - Add category (hold icon)\n" .
                    TF::YELLOW . "/{$label} removecategory <n>" . TF::GRAY . " - Remove category\n" .
                    TF::YELLOW . "/{$label} additem <cat> <price>" . TF::GRAY . " - Add item (hold it)\n" .
                    TF::YELLOW . "/{$label} removeitem <cat>" . TF::GRAY . " - Remove item (hold it)\n" .
                    TF::YELLOW . "/sell [hand|all]" . TF::GRAY . " - Sell items\n" .
                    TF::YELLOW . "/balance [player]" . TF::GRAY . " - Check balance\n" .
                    TF::YELLOW . "/pay <player> <amount>" . TF::GRAY . " - Pay player"
                );
                break;

            default:
                $this->economy_shop->send($sender);
                break;
        }
    }

    // ─── /sell [hand|all] ─────────────────────────────────────────
    private function handleSellCommand(Player $player, array $args): void {
        $mode = strtolower($args[0] ?? "hand");
        if ($mode === "all") {
            $this->sellAll($player);
        } else {
            $this->sellHand($player);
        }
    }

    private function sellHand(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage(TF::RED . "You have nothing in your hand!");
            return;
        }

        $sellPrice = $this->economy_shop->getSellPrice($item);
        if ($sellPrice === null) {
            $player->sendMessage(TF::RED . $item->getName() . " cannot be sold in this shop!");
            return;
        }

        $amount = $item->getCount();
        $total  = $sellPrice * $amount;

        $player->getInventory()->removeItem($item);
        EconomyManager::get()->addMoney(PlayerIdentity::fromPlayer($player), $total);

        $player->sendMessage(
            TF::GREEN . "Sold " . TF::YELLOW . $amount . "x " . $item->getName() .
            TF::GREEN . " for " . TF::GOLD . EconomyManager::get()->formatMoney($total) . TF::GREEN . "!"
        );
    }

    private function sellAll(Player $player): void {
        $inventory   = $player->getInventory();
        $totalEarned = 0.0;
        $soldCount   = 0;
        $toRemove    = [];

        foreach ($inventory->getContents() as $item) {
            if ($item->isNull()) continue;
            $sellPrice = $this->economy_shop->getSellPrice($item);
            if ($sellPrice !== null) {
                $totalEarned += $sellPrice * $item->getCount();
                $soldCount   += $item->getCount();
                $toRemove[]   = clone $item;
            }
        }

        if ($soldCount === 0) {
            $player->sendMessage(TF::RED . "No sellable items in your inventory!");
            return;
        }

        foreach ($toRemove as $item) {
            $inventory->removeItem($item);
        }

        EconomyManager::get()->addMoney(PlayerIdentity::fromPlayer($player), $totalEarned);
        $player->sendMessage(
            TF::GREEN . "Sold " . TF::YELLOW . $soldCount . " items" .
            TF::GREEN . " for " . TF::GOLD . EconomyManager::get()->formatMoney($totalEarned) . TF::GREEN . "!"
        );
    }

    // ─── /balance [player] ────────────────────────────────────────
    private function handleBalanceCommand(Player $sender, array $args): void {
        if (isset($args[0])) {
            $targetName = $args[0];
            // Try online player first for correct UUID
            $target = $this->getServer()->getPlayerByPrefix($targetName);
            $identity = $target !== null
                ? PlayerIdentity::fromPlayer($target)
                : PlayerIdentity::fromName($targetName);
        } else {
            $targetName = $sender->getName();
            $identity   = PlayerIdentity::fromPlayer($sender);
        }

        EconomyManager::get()->getMoney($identity, function(float $money) use($sender, $targetName): void {
            $formatted = EconomyManager::get()->formatMoney($money);
            if (strtolower($targetName) === strtolower($sender->getName())) {
                $sender->sendMessage(TF::GOLD . "Your balance: " . TF::GREEN . $formatted);
            } else {
                $sender->sendMessage(TF::GOLD . $targetName . "'s balance: " . TF::GREEN . $formatted);
            }
        });
    }

    // ─── /pay <player> <amount> ───────────────────────────────────
    private function handlePayCommand(Player $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage(TF::RED . "Usage: /pay <player> <amount>");
            return;
        }

        $target = $this->getServer()->getPlayerByPrefix($args[0]);
        if ($target === null) {
            $sender->sendMessage(TF::RED . "Player \"" . $args[0] . "\" is not online!");
            return;
        }

        $amount = (float) $args[1];
        if ($amount <= 0) {
            $sender->sendMessage(TF::RED . "Amount must be greater than 0.");
            return;
        }

        if (strtolower($sender->getName()) === strtolower($target->getName())) {
            $sender->sendMessage(TF::RED . "You cannot pay yourself!");
            return;
        }

        $senderIdentity = PlayerIdentity::fromPlayer($sender);
        $targetIdentity = PlayerIdentity::fromPlayer($target);
        $economy        = EconomyManager::get();

        $economy->removeMoney($senderIdentity, $amount, function(bool $success) use($sender, $target, $senderIdentity, $targetIdentity, $economy, $amount): void {
            if (!$success) {
                $economy->getMoney($senderIdentity, function(float $bal) use($sender, $economy): void {
                    $sender->sendMessage(TF::RED . "Not enough money! Balance: " . TF::GOLD . $economy->formatMoney($bal));
                });
                return;
            }
            $economy->addMoney($targetIdentity, $amount);
            $fmt = $economy->formatMoney($amount);
            $sender->sendMessage(TF::GREEN . "Paid " . TF::GOLD . $fmt . TF::GREEN . " to " . TF::WHITE . $target->getName() . TF::GREEN . "!");
            $target->sendMessage(TF::GREEN . "You received " . TF::GOLD . $fmt . TF::GREEN . " from " . TF::WHITE . $sender->getName() . TF::GREEN . "!");
        });
    }
}
