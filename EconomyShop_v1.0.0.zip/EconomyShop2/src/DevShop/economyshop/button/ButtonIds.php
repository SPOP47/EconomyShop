<?php

declare(strict_types=1);

namespace DevShop\economyshop\button;

interface ButtonIds{

	public const CATEGORY = "category";
	public const TURN_LEFT = "turn_left";
	public const TURN_RIGHT = "turn_right";
	public const CATEGORIES = "categories";
}