<?php

declare(strict_types=1);

namespace DevShop\economyshop\button;

use DevShop\economyshop\category\Category;
use pocketmine\player\Player;

interface CategoryNavigationButton{

	public function navigate(Player $player, Category $category, int $current_page) : void;
}