<?php

declare(strict_types=1);

namespace DevShop\economyshop\button;

use DevShop\economyshop\category\Category;
use DevShop\economyshop\EconomyShop;
use DevShop\economyshop\Loader;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class CategoriesButton extends Button implements CategoryNavigationButton{

	private static Item $item;
	private static EconomyShop $shop;

	public static function init(Loader $loader, Config $config) : void{
		self::$shop = $loader->getEconomyShop();
		self::$item = ButtonUtils::itemFromConfig($config->get("categories"));
	}

	public static function from(Item $item, CompoundTag $nbt) : self{
		return new self();
	}

	public function getItem() : Item{
		return clone self::$item;
	}

	public function navigate(Player $player, Category $category, int $current_page) : void{
		self::$shop->send($player);
	}
}