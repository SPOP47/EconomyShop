<?php

declare(strict_types=1);

namespace DevShop\economyshop\command;

use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class MoneyCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct("money", "Balance dekho", "/money [player]", ["bal", "balance", "mymoney"]);
        $this->setPermission("economyshop.money");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return true;

        if (isset($args[0])) {
            $targetName = $args[0];
            $bal = $this->plugin->getMoney($targetName);
            $sender->sendMessage($this->plugin->getMessage("balance-other", [
                "player"  => $targetName,
                "balance" => $this->plugin->formatMoney($bal),
            ]));
        } else {
            if (!$sender instanceof Player) {
                $sender->sendMessage(TF::RED . "Player naam do!");
                return true;
            }
            $bal = $this->plugin->getMoney($sender->getName());
            $sender->sendMessage($this->plugin->getMessage("balance-self", [
                "balance" => $this->plugin->formatMoney($bal),
            ]));
        }

        return true;
    }
}
