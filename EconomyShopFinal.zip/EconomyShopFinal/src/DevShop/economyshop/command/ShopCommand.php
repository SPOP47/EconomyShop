<?php

declare(strict_types=1);

namespace DevShop\economyshop\command;

use DevShop\economyshop\Main;
use DevShop\economyshop\ui\ShopUI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct("shop", "Shop GUI kholo", "/shop", ["es", "store"]);
        $this->setPermission("economyshop.shop");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TF::RED . "Sirf in-game use karo!");
            return true;
        }
        if (!$this->testPermission($sender)) return true;

        ShopUI::openShopMenu($sender, $this->plugin);
        return true;
    }
}
