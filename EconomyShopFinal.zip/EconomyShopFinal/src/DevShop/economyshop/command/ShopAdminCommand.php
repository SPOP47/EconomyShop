<?php

declare(strict_types=1);

namespace DevShop\economyshop\command;

use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopAdminCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct("shopadmin", "Shop admin commands", "/shopadmin", ["sa"]);
        $this->setPermission("economyshop.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return true;

        if (count($args) < 1) {
            $this->sendHelp($sender, $commandLabel);
            return true;
        }

        switch (strtolower($args[0])) {

            case "additem":
                // /sa additem <category> <buy_price> <sell_price>
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game use karo!"); return true; }
                if (count($args) < 4) {
                    $sender->sendMessage(TF::RED . "Usage: /{$commandLabel} additem <category> <buy> <sell>");
                    $sender->sendMessage(TF::GRAY . "Haath mein woh item rakho jo add karna hai");
                    return true;
                }
                $catId    = $args[1];
                $buyPrice = (float)$args[2];
                $sellPrice= (float)$args[3];

                $cats = $this->plugin->getShopCategories();
                if (!isset($cats[$catId])) {
                    $sender->sendMessage(TF::RED . "Category \"$catId\" nahi mili! Available: " . implode(", ", array_keys($cats)));
                    return true;
                }

                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Haath mein item rakho!");
                    return true;
                }

                // Get item string ID
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                $this->plugin->addItemToShop($catId, $itemId, $item->getName(), $buyPrice, $sellPrice);

                $sender->sendMessage($this->plugin->getMessage("item-added", [
                    "item"     => $item->getName(),
                    "category" => $catId,
                    "price"    => $this->plugin->formatMoney($buyPrice),
                ]));
                break;

            case "removeitem":
                // /sa removeitem <category>
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game use karo!"); return true; }
                if (count($args) < 2) {
                    $sender->sendMessage(TF::RED . "Usage: /{$commandLabel} removeitem <category>");
                    $sender->sendMessage(TF::GRAY . "Haath mein woh item rakho jo remove karna hai");
                    return true;
                }
                $catId = $args[1];
                $item  = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Haath mein item rakho!");
                    return true;
                }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                if ($this->plugin->removeItemFromShop($catId, $itemId)) {
                    $sender->sendMessage($this->plugin->getMessage("item-removed", [
                        "item"     => $item->getName(),
                        "category" => $catId,
                    ]));
                } else {
                    $sender->sendMessage(TF::RED . "Item \"" . $item->getName() . "\" category \"$catId\" mein nahi mila!");
                }
                break;

            case "reload":
                $this->plugin->saveResource("shop.yml");
                $sender->sendMessage(TF::GREEN . "Shop config reload ho gaya!");
                break;

            case "help":
            default:
                $this->sendHelp($sender, $commandLabel);
                break;
        }

        return true;
    }

    private function sendHelp(CommandSender $sender, string $label): void {
        $sender->sendMessage(
            TF::GOLD . TF::BOLD . "=== ShopAdmin Commands ===" . TF::RESET . "\n" .
            TF::YELLOW . "/{$label} additem <cat> <buy> <sell>" . TF::GRAY . " - Item add karo (haath mein rakho)\n" .
            TF::YELLOW . "/{$label} removeitem <cat>" . TF::GRAY . " - Item remove karo (haath mein rakho)\n" .
            TF::YELLOW . "/{$label} reload" . TF::GRAY . " - Config reload karo\n" .
            TF::YELLOW . "/{$label} help" . TF::GRAY . " - Ye message\n" .
            TF::AQUA . "Categories: " . TF::WHITE . implode(", ", array_keys($this->plugin->getShopCategories()))
        );
    }
}
