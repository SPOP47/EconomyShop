<?php

declare(strict_types=1);

namespace DevShop\economyshop\ui;

use DevShop\economyshop\Main;
use DevShop\economyshop\libs\muqsit\invmenu\InvMenu;
use DevShop\economyshop\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopUI {

    // ── Glass Filler ─────────────────────────────────────────────
    private static function glass(): Item {
        $item = VanillaBlocks::GRAY_STAINED_GLASS_PANE()->asItem();
        $item->setCustomName(TF::RESET . " ");
        return $item;
    }

    private static function fillBorder(InvMenu $menu, int $size = 54): void {
        $inv = $menu->getInventory();
        $border = [];
        for ($i = 0; $i < 9; $i++) $border[] = $i;
        for ($i = $size - 9; $i < $size; $i++) $border[] = $i;
        for ($i = 9; $i < $size - 9; $i += 9) { $border[] = $i; $border[] = $i + 8; }
        foreach ($border as $slot) {
            $inv->setItem($slot, self::glass());
        }
    }

    // ── /shop - Main Category Menu ────────────────────────────────
    public static function openShopMenu(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::GOLD . TF::BOLD . "» EconomyShop «");
        self::fillBorder($menu);

        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();

        // Category slots: 10,11,12,13,14,15,16 / 19-25 / 28-34 / 37-43
        $availSlots = [10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42,43];
        $slotIdx = 0;

        foreach ($categories as $catId => $catData) {
            if ($slotIdx >= count($availSlots)) break;

            $icon = StringToItemParser::getInstance()->parse($catData["icon"] ?? "chest");
            if ($icon === null || $icon->isNull()) {
                $icon = VanillaBlocks::CHEST()->asItem();
            }

            $catName   = TF::colorize($catData["name"] ?? $catId);
            $itemCount = count($catData["items"] ?? []);

            $icon->setCustomName($catName);
            $icon->setLore([
                TF::GRAY . $itemCount . " items",
                TF::YELLOW . "Click to browse!",
            ]);

            $nbt = $icon->getNamedTag();
            $nbt->setString("es_cat", $catId);
            $icon->setNamedTag($nbt);

            $menu->getInventory()->setItem($availSlots[$slotIdx], $icon);
            $slotIdx++;
        }

        // Balance display slot 49
        $bal = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $menu->getInventory()->setItem(49, $balItem);

        $menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $t) use($plugin): void {
            $player = $t->getPlayer();
            $item   = $t->getItemClicked();
            $catId  = $item->getNamedTag()->getString("es_cat", "");
            if ($catId !== "") {
                $player->removeCurrentWindow();
                $t->then(fn(Player $p) => self::openCategoryItems($p, $plugin, $catId));
            }
        }));

        $menu->send($player);
    }

    // ── /shop - Category Items ────────────────────────────────────
    public static function openCategoryItems(Player $player, Main $plugin, string $catId): void {
        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();
        $catData    = $categories[$catId] ?? null;

        if ($catData === null) {
            $player->sendMessage(TF::RED . "Category not found!");
            return;
        }

        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $catName = TF::colorize($catData["name"] ?? $catId);
        $menu->setName(TF::GOLD . TF::BOLD . "» " . strip_tags($catName) . " «");
        self::fillBorder($menu);

        // Back button slot 45
        $back = VanillaBlocks::BRICK_STAIRS()->asItem();
        $back->setCustomName(TF::RED . TF::BOLD . "« Back");
        $back->setLore([TF::GRAY . "Return to categories"]);
        $nbt = $back->getNamedTag();
        $nbt->setString("es_action", "back");
        $back->setNamedTag($nbt);
        $menu->getInventory()->setItem(45, $back);

        // Balance slot 49
        $bal = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $menu->getInventory()->setItem(49, $balItem);

        $availSlots = [10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42,43];
        $slotIdx = 0;

        foreach (($catData["items"] ?? []) as $itemId) {
            if ($slotIdx >= count($availSlots)) break;
            $itemData = $allItems[$itemId] ?? null;
            if ($itemData === null) continue;

            $item = StringToItemParser::getInstance()->parse($itemId);
            if ($item === null || $item->isNull()) continue;

            $buyPrice  = (float)($itemData["buy"]  ?? 0);
            $sellPrice = (float)($itemData["sell"] ?? 0);
            $name      = $itemData["name"] ?? $item->getName();

            $item->setCustomName(TF::YELLOW . TF::BOLD . $name);
            $item->setLore([
                TF::GREEN  . "Buy:  " . TF::WHITE . ($buyPrice > 0  ? $plugin->formatMoney($buyPrice)  : TF::RED . "N/A"),
                TF::AQUA   . "Sell: " . TF::WHITE . ($sellPrice > 0 ? $plugin->formatMoney($sellPrice) : TF::RED . "N/A"),
                "",
                TF::YELLOW . "Left Click  » Buy x1",
                TF::YELLOW . "Right Click » Buy x64",
            ]);

            $nbt = $item->getNamedTag();
            $nbt->setString("es_action", "buy");
            $nbt->setString("es_item", $itemId);
            $item->setNamedTag($nbt);

            $menu->getInventory()->setItem($availSlots[$slotIdx], $item);
            $slotIdx++;
        }

        $menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $t) use($plugin, $catId): void {
            $player = $t->getPlayer();
            $item   = $t->getItemClicked();
            $nbt    = $item->getNamedTag();
            $action = $nbt->getString("es_action", "");

            if ($action === "back") {
                $player->removeCurrentWindow();
                $t->then(fn(Player $p) => self::openShopMenu($p, $plugin));
                return;
            }

            if ($action === "buy") {
                $itemId = $nbt->getString("es_item", "");
                // Right click = 64, left click = 1
                $amount = 1;
                self::processBuy($player, $plugin, $itemId, $amount);
            }
        }));

        $menu->send($player);
    }

    // ── Process Buy ───────────────────────────────────────────────
    public static function processBuy(Player $player, Main $plugin, string $itemId, int $amount = 1): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) {
            $player->sendMessage(TF::RED . "Item not found in shop!");
            return;
        }

        $buyPrice = (float)($itemData["buy"] ?? 0);
        if ($buyPrice <= 0) {
            $player->sendMessage(TF::RED . "Ye item kharida nahi ja sakta!");
            return;
        }

        $total = $buyPrice * $amount;
        $bal   = $plugin->getMoney($player->getName());

        if ($bal < $total) {
            $player->sendMessage($plugin->getMessage("not-enough-money", [
                "balance" => $plugin->formatMoney($bal)
            ]));
            return;
        }

        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null || $item->isNull()) {
            $player->sendMessage(TF::RED . "Item resolve nahi hua: " . $itemId);
            return;
        }

        $item->setCount($amount);
        if (!$player->getInventory()->canAddItem($item)) {
            $player->sendMessage($plugin->getMessage("inventory-full"));
            return;
        }

        $plugin->reduceMoney($player->getName(), $total);
        $player->getInventory()->addItem($item);

        $player->sendMessage($plugin->getMessage("buy-success", [
            "amount"  => $amount,
            "item"    => $itemData["name"] ?? $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── /sell - Sell Chest GUI ────────────────────────────────────
    public static function openSellMenu(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::AQUA . TF::BOLD . "» Sell Items «");

        // Info item slot 4
        $info = VanillaBlocks::EMERALD_ORE()->asItem();
        $info->setCustomName(TF::GREEN . TF::BOLD . "SELL CHEST");
        $info->setLore([
            TF::GRAY . "Items yahan rakh ke sell karo!",
            TF::YELLOW . "Valid items bik jayenge",
            TF::RED . "Invalid items wapis milenge",
        ]);

        // Sell button slot 49
        $sellBtn = VanillaBlocks::EMERALD_BLOCK()->asItem();
        $sellBtn->setCustomName(TF::GREEN . TF::BOLD . "» SELL ALL «");
        $sellBtn->setLore([TF::GRAY . "Sab valid items sell karo"]);
        $nbtSell = $sellBtn->getNamedTag();
        $nbtSell->setString("es_action", "sell_confirm");
        $sellBtn->setNamedTag($nbtSell);

        // Cancel button slot 45
        $cancelBtn = VanillaBlocks::REDSTONE_BLOCK()->asItem();
        $cancelBtn->setCustomName(TF::RED . TF::BOLD . "» CANCEL «");
        $cancelBtn->setLore([TF::GRAY . "Items wapis leke band karo"]);
        $nbtCancel = $cancelBtn->getNamedTag();
        $nbtCancel->setString("es_action", "sell_cancel");
        $cancelBtn->setNamedTag($nbtCancel);

        // Glass border on top row and bottom row
        $glass = self::glass();
        for ($i = 0; $i < 9; $i++) $menu->getInventory()->setItem($i, $glass);
        for ($i = 45; $i < 54; $i++) $menu->getInventory()->setItem($i, $glass);

        $menu->getInventory()->setItem(4, $info);
        $menu->getInventory()->setItem(45, $cancelBtn);
        $menu->getInventory()->setItem(49, $sellBtn);
        $menu->getInventory()->setItem(53, $cancelBtn);

        // Slots 9-44 are FREE for player to put items (middle area)

        $menu->setListener(function(DeterministicInvMenuTransaction $t) use($plugin): void {
            $player  = $t->getPlayer();
            $item    = $t->getItemClicked();
            $action  = $item->getNamedTag()->getString("es_action", "");

            if ($action === "sell_cancel") {
                // Return all items from menu to player
                $inv = $t->getAction()->getInventory();
                foreach (range(9, 44) as $slot) {
                    $slotItem = $inv->getItem($slot);
                    if (!$slotItem->isNull()) {
                        foreach ($player->getInventory()->addItem($slotItem) as $dropped) {
                            $player->getWorld()->dropItem($player->getPosition(), $dropped);
                        }
                        $inv->setItem($slot, VanillaItems::AIR());
                    }
                }
                $player->removeCurrentWindow();
                return;
            }

            if ($action === "sell_confirm") {
                $inv = $t->getAction()->getInventory();
                $totalEarned = 0.0;
                $soldCount   = 0;
                $returnItems = [];

                foreach (range(9, 44) as $slot) {
                    $slotItem = $inv->getItem($slot);
                    if ($slotItem->isNull()) continue;

                    // Find sell price
                    $found = false;
                    foreach ($plugin->getShopItems() as $itemId => $data) {
                        $sellPrice = (float)($data["sell"] ?? 0);
                        if ($sellPrice <= 0) continue;

                        $testItem = StringToItemParser::getInstance()->parse($itemId);
                        if ($testItem !== null && $testItem->getTypeId() === $slotItem->getTypeId()) {
                            $totalEarned += $sellPrice * $slotItem->getCount();
                            $soldCount   += $slotItem->getCount();
                            $inv->setItem($slot, VanillaItems::AIR());
                            $found = true;
                            break;
                        }
                    }

                    if (!$found) {
                        $returnItems[] = clone $slotItem;
                        $inv->setItem($slot, VanillaItems::AIR());
                    }
                }

                // Give money
                if ($soldCount > 0) {
                    $plugin->addMoney($player->getName(), $totalEarned);
                    $player->sendMessage($plugin->getMessage("sell-success", [
                        "amount"  => $soldCount,
                        "item"    => "items",
                        "price"   => $plugin->formatMoney($totalEarned),
                        "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
                    ]));
                } else {
                    $player->sendMessage($plugin->getMessage("sell-nothing"));
                }

                // Return invalid items
                foreach ($returnItems as $ri) {
                    $notAdded = $player->getInventory()->addItem($ri);
                    foreach ($notAdded as $drop) {
                        $player->getWorld()->dropItem($player->getPosition(), $drop);
                    }
                    if (!empty($notAdded) || true) {
                        $player->sendMessage($plugin->getMessage("sell-invalid", ["item" => $ri->getName()]));
                    }
                }

                $player->removeCurrentWindow();
                return;
            }

            // Block click on top/bottom rows (glass, info, buttons)
            $slot = $t->getAction()->getSlot();
            if ($slot < 9 || $slot >= 45) {
                $t->discard();
            }
            // Slots 9-44: player can freely put/take items
        });

        $menu->send($player);
    }
}
