<?php

declare(strict_types=1);

namespace DevShop\economyshop\ui;

use DevShop\economyshop\Main;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopUI {

    // ── /shop - Categories ────────────────────────────────────────
    public static function openMainShop(Player $player, Main $plugin): void {
        $categories = $plugin->getShopCategories();
        $bal        = $plugin->formatMoney($plugin->getMoney($player->getName()));

        $buttons = [];
        $catIds  = [];

        foreach ($categories as $catId => $catData) {
            $name       = TF::colorize($catData["name"] ?? $catId);
            $itemCount  = count($catData["items"] ?? []);
            $buttons[]  = ["text" => $name . "\n§7" . $itemCount . " items"];
            $catIds[]   = $catId;
        }

        $form = [
            "type"    => "form",
            "title"   => "§6§l» EconomyShop «",
            "content" => "§eBalance: §a" . $bal . "\n§7Category choose karo:",
            "buttons" => $buttons,
        ];

        $player->sendForm(new class($form, $catIds, $plugin) implements \pocketmine\form\Form {
            public function __construct(
                private array $formData,
                private array $catIds,
                private Main $plugin
            ) {}

            public function jsonSerialize(): mixed {
                return $this->formData;
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null || !isset($this->catIds[$data])) return;
                ShopUI::openCategory($player, $this->plugin, $this->catIds[$data]);
            }
        });
    }

    // ── /shop - Category Items ────────────────────────────────────
    public static function openCategory(Player $player, Main $plugin, string $catId): void {
        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();
        $catData    = $categories[$catId] ?? null;

        if ($catData === null) {
            $player->sendMessage(TF::RED . "Category nahi mili!");
            return;
        }

        $catName = TF::colorize($catData["name"] ?? $catId);
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));

        $buttons = [];
        $itemIds = [];

        // Back button
        $buttons[] = ["text" => "§c§l« Wapas Jao"];
        $itemIds[]  = "__back__";

        foreach (($catData["items"] ?? []) as $itemId) {
            $itemData = $allItems[$itemId] ?? null;
            if ($itemData === null) continue;

            $buy  = (float) ($itemData["buy"]  ?? 0);
            $sell = (float) ($itemData["sell"] ?? 0);
            $name = $itemData["name"] ?? $itemId;

            $buyText  = $buy  > 0 ? "§aBuy: §f"  . $plugin->formatMoney($buy)  : "§cBuy: N/A";
            $sellText = $sell > 0 ? "§bSell: §f" . $plugin->formatMoney($sell) : "§cSell: N/A";

            $buttons[] = ["text" => "§e§l" . $name . "\n" . $buyText . "  " . $sellText];
            $itemIds[]  = $itemId;
        }

        $form = [
            "type"    => "form",
            "title"   => "§6§l" . strip_tags($catName),
            "content" => "§eBalance: §a" . $bal . "\n§7Item choose karo:",
            "buttons" => $buttons,
        ];

        $player->sendForm(new class($form, $itemIds, $catId, $plugin) implements \pocketmine\form\Form {
            public function __construct(
                private array $formData,
                private array $itemIds,
                private string $catId,
                private Main $plugin
            ) {}

            public function jsonSerialize(): mixed {
                return $this->formData;
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null || !isset($this->itemIds[$data])) return;

                $itemId = $this->itemIds[$data];

                if ($itemId === "__back__") {
                    ShopUI::openMainShop($player, $this->plugin);
                    return;
                }

                ShopUI::openBuyMenu($player, $this->plugin, $itemId, $this->catId);
            }
        });
    }

    // ── Buy Amount Menu ───────────────────────────────────────────
    public static function openBuyMenu(Player $player, Main $plugin, string $itemId, string $catId): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) return;

        $name     = $itemData["name"] ?? $itemId;
        $buy      = (float) ($itemData["buy"]  ?? 0);
        $sell     = (float) ($itemData["sell"] ?? 0);
        $bal      = $plugin->getMoney($player->getName());

        if ($buy <= 0) {
            $player->sendMessage(TF::RED . $name . " kharida nahi ja sakta!");
            self::openCategory($player, $plugin, $catId);
            return;
        }

        $amounts  = [1, 8, 16, 32, 64];
        $buttons  = [];

        foreach ($amounts as $amt) {
            $total    = $buy * $amt;
            $canBuy   = $bal >= $total;
            $color    = $canBuy ? "§a" : "§c";
            $buttons[] = ["text" => $color . "§lBuy x" . $amt . "\n§f" . $plugin->formatMoney($total)];
        }

        $buttons[] = ["text" => "§c§l« Wapas Jao"];

        $form = [
            "type"    => "form",
            "title"   => "§6§l" . $name,
            "content" =>
                "§eBuy: §a" . $plugin->formatMoney($buy) . " / item\n" .
                "§bSell: §a" . ($sell > 0 ? $plugin->formatMoney($sell) : "N/A") . "\n" .
                "§eBalance: §a" . $plugin->formatMoney($bal) . "\n\n" .
                "§7Kitna kharidna hai?",
            "buttons" => $buttons,
        ];

        $player->sendForm(new class($form, $amounts, $itemId, $catId, $plugin) implements \pocketmine\form\Form {
            public function __construct(
                private array $formData,
                private array $amounts,
                private string $itemId,
                private string $catId,
                private Main $plugin
            ) {}

            public function jsonSerialize(): mixed {
                return $this->formData;
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;

                // Last button = back
                if ($data >= count($this->amounts)) {
                    ShopUI::openCategory($player, $this->plugin, $this->catId);
                    return;
                }

                $amount = $this->amounts[$data];
                ShopUI::processBuy($player, $this->plugin, $this->itemId, $amount, $this->catId);
            }
        });
    }

    // ── Buy Logic ─────────────────────────────────────────────────
    public static function processBuy(Player $player, Main $plugin, string $itemId, int $amount, string $catId): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) {
            $player->sendMessage(TF::RED . "Item shop mein nahi hai!");
            return;
        }

        $buyPrice = (float) ($itemData["buy"] ?? 0);
        if ($buyPrice <= 0) {
            $player->sendMessage(TF::RED . "Ye item kharida nahi ja sakta!");
            return;
        }

        $total = $buyPrice * $amount;
        $bal   = $plugin->getMoney($player->getName());

        if ($bal < $total) {
            $player->sendMessage($plugin->getMessage("not-enough-money", [
                "balance" => $plugin->formatMoney($bal),
            ]));
            return;
        }

        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null || $item->isNull()) {
            $player->sendMessage(TF::RED . "Item error: " . $itemId);
            return;
        }

        $item->setCount($amount);

        if (!$player->getInventory()->canAddItem($item)) {
            $player->sendMessage($plugin->getMessage("inventory-full"));
            return;
        }

        $plugin->reduceMoney($player->getName(), $total);
        $player->getInventory()->addItem($item);

        $player->sendMessage($plugin->getMessage("buy-success", [
            "amount"  => $amount,
            "item"    => $itemData["name"] ?? $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── /sell Menu ────────────────────────────────────────────────
    public static function openSellMenu(Player $player, Main $plugin): void {
        $handItem = $player->getInventory()->getItemInHand();
        $bal      = $plugin->formatMoney($plugin->getMoney($player->getName()));

        $content = "§eBalance: §a" . $bal . "\n\n";

        if (!$handItem->isNull()) {
            $sellPrice = self::getSellPrice($handItem, $plugin);
            if ($sellPrice !== null) {
                $total    = $sellPrice * $handItem->getCount();
                $content .= "§7Haath mein: §e" . $handItem->getName() . " §7x" . $handItem->getCount() . "\n";
                $content .= "§bSell Value: §a" . $plugin->formatMoney($total) . "\n\n";
            } else {
                $content .= "§7Haath mein: §e" . $handItem->getName() . " §c(Nahi bikta)\n\n";
            }
        } else {
            $content .= "§7Haath mein kuch nahi hai\n\n";
        }

        $content .= "§7Kya bechna chahte ho?";

        $form = [
            "type"    => "form",
            "title"   => "§b§l» Sell Items «",
            "content" => $content,
            "buttons" => [
                ["text" => "§a§lSell Hand\n§7Haath wala item becho"],
                ["text" => "§6§lSell All\n§7Sab sellable items becho"],
                ["text" => "§c§l« Band Karo"],
            ],
        ];

        $player->sendForm(new class($form, $plugin) implements \pocketmine\form\Form {
            public function __construct(
                private array $formData,
                private Main $plugin
            ) {}

            public function jsonSerialize(): mixed {
                return $this->formData;
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                match ((int) $data) {
                    0 => ShopUI::sellHand($player, $this->plugin),
                    1 => ShopUI::sellAll($player, $this->plugin),
                    default => null,
                };
            }
        });
    }

    // ── Sell Hand ─────────────────────────────────────────────────
    public static function sellHand(Player $player, Main $plugin): void {
        $item = $player->getInventory()->getItemInHand();

        if ($item->isNull()) {
            $player->sendMessage(TF::RED . "Haath mein kuch nahi hai!");
            return;
        }

        $sellPrice = self::getSellPrice($item, $plugin);
        if ($sellPrice === null) {
            $player->sendMessage($plugin->getMessage("sell-invalid", ["item" => $item->getName()]));
            return;
        }

        $amount = $item->getCount();
        $total  = $sellPrice * $amount;

        $player->getInventory()->removeItem($item);
        $plugin->addMoney($player->getName(), $total);

        $player->sendMessage($plugin->getMessage("sell-success", [
            "amount"  => $amount,
            "item"    => $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── Sell All ──────────────────────────────────────────────────
    public static function sellAll(Player $player, Main $plugin): void {
        $inventory   = $player->getInventory();
        $totalEarned = 0.0;
        $soldCount   = 0;
        $toRemove    = [];

        foreach ($inventory->getContents() as $item) {
            if ($item->isNull()) continue;
            $sellPrice = self::getSellPrice($item, $plugin);
            if ($sellPrice !== null) {
                $totalEarned += $sellPrice * $item->getCount();
                $soldCount   += $item->getCount();
                $toRemove[]   = clone $item;
            }
        }

        if ($soldCount === 0) {
            $player->sendMessage($plugin->getMessage("sell-nothing"));
            return;
        }

        foreach ($toRemove as $item) {
            $inventory->removeItem($item);
        }

        $plugin->addMoney($player->getName(), $totalEarned);
        $player->sendMessage($plugin->getMessage("sell-all-success", [
            "amount"  => $soldCount,
            "price"   => $plugin->formatMoney($totalEarned),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── Get Sell Price ─────────────────────────────────────────────
    public static function getSellPrice(\pocketmine\item\Item $item, Main $plugin): ?float {
        foreach ($plugin->getShopItems() as $itemId => $data) {
            $sellPrice = (float) ($data["sell"] ?? 0);
            if ($sellPrice <= 0) continue;
            $test = StringToItemParser::getInstance()->parse($itemId);
            if ($test !== null && !$test->isNull() && $test->getTypeId() === $item->getTypeId()) {
                return $sellPrice;
            }
        }
        return null;
    }
}
