<?php
declare(strict_types=1);
namespace DevShop\economyshop\command;
use DevShop\economyshop\Main;
use DevShop\economyshop\ui\ShopUI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;
class ShopCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("shop", "Shop GUI kholo", "/shop", []);
        $this->setPermission("economyshop.use");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game only!"); return true; }
        if (!$this->testPermission($sender)) return true;
        ShopUI::openMainShop($sender, $this->plugin);
        return true;
    }
}
