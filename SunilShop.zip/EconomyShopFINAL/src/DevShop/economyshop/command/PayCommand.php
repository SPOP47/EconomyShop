<?php
declare(strict_types=1);
namespace DevShop\economyshop\command;
use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;
class PayCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("pay", "Paise do", "/pay <player> <amount>", []);
        $this->setPermission("economyshop.use");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game only!"); return true; }
        if (!$this->testPermission($sender)) return true;
        if (count($args) < 2) { $sender->sendMessage(TF::RED . "Usage: /pay <player> <amount>"); return true; }
        $targetName = $args[0];
        $amount = (float) $args[1];
        if ($amount <= 0) { $sender->sendMessage(TF::RED . "Amount 0 se zyada hona chahiye!"); return true; }
        if (strtolower($sender->getName()) === strtolower($targetName)) { $sender->sendMessage(TF::RED . "Khud ko pay nahi kar sakte!"); return true; }
        $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($target === null) { $sender->sendMessage(TF::RED . $targetName . " online nahi hai!"); return true; }
        $bal = $this->plugin->getMoney($sender->getName());
        if ($bal < $amount) {
            $sender->sendMessage($this->plugin->getMessage("not-enough-money", ["balance" => $this->plugin->formatMoney($bal)]));
            return true;
        }
        $this->plugin->reduceMoney($sender->getName(), $amount);
        $this->plugin->addMoney($target->getName(), $amount);
        $fmt = $this->plugin->formatMoney($amount);
        $sender->sendMessage($this->plugin->getMessage("pay-sent", ["player" => $target->getName(), "amount" => $fmt, "balance" => $this->plugin->formatMoney($this->plugin->getMoney($sender->getName()))]));
        $target->sendMessage($this->plugin->getMessage("pay-received", ["player" => $sender->getName(), "amount" => $fmt, "balance" => $this->plugin->formatMoney($this->plugin->getMoney($target->getName()))]));
        return true;
    }
}
