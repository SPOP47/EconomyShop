<?php
declare(strict_types=1);
namespace DevShop\economyshop\command;
use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;
class ShopAdminCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("shopadmin", "Shop admin", "/shopadmin", ["sa"]);
        $this->setPermission("economyshop.admin");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return true;
        $sub = strtolower($args[0] ?? "help");
        switch ($sub) {
            case "additem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game!"); return true; }
                if (count($args) < 4) { $sender->sendMessage(TF::RED . "Usage: /sa additem <cat> <buy> <sell> (haath mein item rakho)"); return true; }
                $cats = $this->plugin->getShopCategories();
                if (!isset($cats[$args[1]])) { $sender->sendMessage(TF::RED . "Cat nahi mili! Available: " . implode(", ", array_keys($cats))); return true; }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) { $sender->sendMessage(TF::RED . "Haath mein item rakho!"); return true; }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                $this->plugin->addItemToShop($args[1], $itemId, $item->getName(), (float)$args[2], (float)$args[3]);
                $sender->sendMessage(TF::GREEN . "Added: " . $item->getName() . " to " . $args[1]);
                break;
            case "removeitem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game!"); return true; }
                if (count($args) < 2) { $sender->sendMessage(TF::RED . "Usage: /sa removeitem <cat>"); return true; }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) { $sender->sendMessage(TF::RED . "Haath mein item rakho!"); return true; }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                if ($this->plugin->removeItemFromShop($args[1], $itemId)) {
                    $sender->sendMessage(TF::GREEN . "Removed: " . $item->getName());
                } else {
                    $sender->sendMessage(TF::RED . "Item nahi mila!");
                }
                break;
            case "reload":
                $this->plugin->reloadShop();
                $sender->sendMessage(TF::GREEN . "Shop reloaded!");
                break;
            default:
                $sender->sendMessage(TF::GOLD . "=== ShopAdmin ===" . "\n" .
                    TF::YELLOW . "/sa additem <cat> <buy> <sell>\n" .
                    TF::YELLOW . "/sa removeitem <cat>\n" .
                    TF::YELLOW . "/sa reload\n" .
                    TF::AQUA . "Cats: " . implode(", ", array_keys($this->plugin->getShopCategories())));
        }
        return true;
    }
}
