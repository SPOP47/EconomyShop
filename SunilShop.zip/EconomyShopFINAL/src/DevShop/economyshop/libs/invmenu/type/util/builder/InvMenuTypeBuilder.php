<?php

declare(strict_types=1);

namespace muqsit\chestshop\libs\muqsit\invmenu\type\util\builder;

use muqsit\chestshop\libs\muqsit\invmenu\type\InvMenuType;

interface InvMenuTypeBuilder{

	public function build() : InvMenuType;
}