<?php

declare(strict_types=1);

namespace muqsit\chestshop\libs\muqsit\invmenu\session;

use muqsit\chestshop\libs\muqsit\invmenu\InvMenu;
use muqsit\chestshop\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;

final class InvMenuInfo{

	public function __construct(
		readonly public InvMenu $menu,
		readonly public InvMenuGraphic $graphic,
		readonly public ?string $graphic_name
	){}
}