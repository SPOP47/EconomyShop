<?php

declare(strict_types=1);

namespace DevShop\economyshop\ui;

use DevShop\economyshop\Main;
use muqsit\chestshop\libs\muqsit\invmenu\InvMenu;
use muqsit\chestshop\libs\muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\chestshop\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopUI {

    private static function glass(): Item {
        $item = VanillaBlocks::GRAY_STAINED_GLASS_PANE()->asItem();
        $item->setCustomName(TF::RESET . " ");
        return $item;
    }

    private static function borderFill(InvMenu $menu, int $size = 54): void {
        $inv    = $menu->getInventory();
        $border = array_merge(range(0, 8), range($size - 9, $size - 1));
        for ($i = 9; $i < $size - 9; $i += 9) {
            $border[] = $i;
            $border[] = $i + 8;
        }
        foreach ($border as $slot) {
            $inv->setItem($slot, self::glass());
        }
    }

    // ── /shop Main Category Menu ──────────────────────────────────
    public static function openMainShop(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::GOLD . TF::BOLD . "» EconomyShop «");
        self::borderFill($menu);

        $inv        = $menu->getInventory();
        $categories = $plugin->getShopCategories();

        $slots = [
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43,
        ];
        $i = 0;

        foreach ($categories as $catId => $catData) {
            if ($i >= count($slots)) break;

            $iconStr = $catData["icon"] ?? "chest";
            $icon    = StringToItemParser::getInstance()->parse($iconStr)
                    ?? VanillaBlocks::CHEST()->asItem();

            $catName   = TF::colorize($catData["name"] ?? $catId);
            $itemCount = count($catData["items"] ?? []);

            $icon->setCustomName($catName);
            $icon->setLore([
                TF::GRAY . $itemCount . " items",
                TF::YELLOW . "Click to open!",
            ]);

            $nbt = $icon->getNamedTag();
            $nbt->setString("es_cat", $catId);
            $icon->setNamedTag($nbt);

            $inv->setItem($slots[$i++], $icon);
        }

        // Balance at slot 49
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $inv->setItem(49, $balItem);

        $menu->setListener(InvMenu::readonly(
            function (DeterministicInvMenuTransaction $t) use ($plugin): void {
                $player = $t->getPlayer();
                $catId  = $t->getItemClicked()->getNamedTag()->getString("es_cat", "");
                if ($catId !== "") {
                    $player->removeCurrentWindow();
                    $t->then(fn(Player $p) => self::openCategory($p, $plugin, $catId));
                }
            }
        ));

        $menu->send($player);
    }

    // ── Category Items ────────────────────────────────────────────
    public static function openCategory(Player $player, Main $plugin, string $catId): void {
        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();
        $catData    = $categories[$catId] ?? null;

        if ($catData === null) {
            $player->sendMessage(TF::RED . "Category nahi mili!");
            return;
        }

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::GOLD . TF::BOLD . "» " . TF::colorize($catData["name"] ?? $catId) . " «");
        self::borderFill($menu);

        $inv = $menu->getInventory();

        // Back button
        $back = VanillaBlocks::OAK_STAIRS()->asItem();
        $back->setCustomName(TF::RED . TF::BOLD . "« Wapas");
        $back->setLore([TF::GRAY . "Categories mein wapas jao"]);
        $nbt = $back->getNamedTag();
        $nbt->setString("es_action", "back");
        $back->setNamedTag($nbt);
        $inv->setItem(45, $back);

        // Balance
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $inv->setItem(49, $balItem);

        $slots = [
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43,
        ];
        $i = 0;

        foreach (($catData["items"] ?? []) as $itemId) {
            if ($i >= count($slots)) break;
            $itemData = $allItems[$itemId] ?? null;
            if ($itemData === null) continue;

            $item = StringToItemParser::getInstance()->parse($itemId);
            if ($item === null || $item->isNull()) continue;

            $buy  = (float) ($itemData["buy"]  ?? 0);
            $sell = (float) ($itemData["sell"] ?? 0);
            $name = $itemData["name"] ?? $item->getName();

            $item->setCustomName(TF::YELLOW . TF::BOLD . $name);
            $item->setLore([
                TF::GREEN . "Buy:  " . ($buy  > 0 ? TF::WHITE . $plugin->formatMoney($buy)  : TF::RED . "N/A"),
                TF::AQUA  . "Sell: " . ($sell > 0 ? TF::WHITE . $plugin->formatMoney($sell) : TF::RED . "N/A"),
                "",
                TF::YELLOW . "Left Click  = Buy x1",
                TF::YELLOW . "Right Click = Buy x64",
            ]);

            $nbt = $item->getNamedTag();
            $nbt->setString("es_action", "buy");
            $nbt->setString("es_item", $itemId);
            $item->setNamedTag($nbt);

            $inv->setItem($slots[$i++], $item);
        }

        $menu->setListener(InvMenu::readonly(
            function (DeterministicInvMenuTransaction $t) use ($plugin, $catId): void {
                $player = $t->getPlayer();
                $nbt    = $t->getItemClicked()->getNamedTag();
                $action = $nbt->getString("es_action", "");

                if ($action === "back") {
                    $player->removeCurrentWindow();
                    $t->then(fn(Player $p) => self::openMainShop($p, $plugin));
                    return;
                }

                if ($action === "buy") {
                    $itemId = $nbt->getString("es_item", "");
                    // Detect right click = buy 64, left click = buy 1
                    $clickedWith = $t->getItemClickedWith();
                    $amount      = $clickedWith->isNull() ? 1 : 64;
                    self::processBuy($player, $plugin, $itemId, $amount, $catId);
                }
            }
        ));

        $menu->send($player);
    }

    // ── Buy Logic ─────────────────────────────────────────────────
    public static function processBuy(Player $player, Main $plugin, string $itemId, int $amount, string $catId): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) {
            $player->sendMessage(TF::RED . "Item shop mein nahi hai!");
            return;
        }

        $buyPrice = (float) ($itemData["buy"] ?? 0);
        if ($buyPrice <= 0) {
            $player->sendMessage(TF::RED . "Ye item kharida nahi ja sakta!");
            return;
        }

        $total = $buyPrice * $amount;
        $bal   = $plugin->getMoney($player->getName());

        if ($bal < $total) {
            $player->sendMessage($plugin->getMessage("not-enough-money", [
                "balance" => $plugin->formatMoney($bal),
            ]));
            return;
        }

        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null || $item->isNull()) {
            $player->sendMessage(TF::RED . "Item parse error: " . $itemId);
            return;
        }
        $item->setCount($amount);

        if (!$player->getInventory()->canAddItem($item)) {
            $player->sendMessage($plugin->getMessage("inventory-full"));
            return;
        }

        $plugin->reduceMoney($player->getName(), $total);
        $player->getInventory()->addItem($item);

        $player->sendMessage($plugin->getMessage("buy-success", [
            "amount"  => $amount,
            "item"    => $itemData["name"] ?? $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── /sell GUI ─────────────────────────────────────────────────
    public static function openSellMenu(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::AQUA . TF::BOLD . "» Items Becho «");

        $inv = $menu->getInventory();

        // Top row glass
        for ($s = 0; $s < 9; $s++) $inv->setItem($s, self::glass());
        // Bottom row glass
        for ($s = 45; $s < 54; $s++) $inv->setItem($s, self::glass());

        // Info
        $info = VanillaBlocks::EMERALD_ORE()->asItem();
        $info->setCustomName(TF::GREEN . TF::BOLD . "SELL CHEST");
        $info->setLore([
            TF::GRAY . "Neeche items rakh do!",
            TF::YELLOW . "SELL ALL dabao bechne ke liye",
            TF::RED . "Invalid items wapis milenge",
        ]);
        $inv->setItem(4, $info);

        // SELL ALL button
        $sellBtn = VanillaBlocks::EMERALD_BLOCK()->asItem();
        $sellBtn->setCustomName(TF::GREEN . TF::BOLD . "» SELL ALL «");
        $sellBtn->setLore([TF::GRAY . "Sab valid items becho"]);
        $nbtS = $sellBtn->getNamedTag();
        $nbtS->setString("es_action", "do_sell");
        $sellBtn->setNamedTag($nbtS);
        $inv->setItem(49, $sellBtn);

        // Cancel button
        $cancelBtn = VanillaBlocks::REDSTONE_BLOCK()->asItem();
        $cancelBtn->setCustomName(TF::RED . TF::BOLD . "» CANCEL «");
        $cancelBtn->setLore([TF::GRAY . "Items wapis le lo"]);
        $nbtC = $cancelBtn->getNamedTag();
        $nbtC->setString("es_action", "cancel");
        $cancelBtn->setNamedTag($nbtC);
        $inv->setItem(45, $cancelBtn);
        $inv->setItem(53, $cancelBtn);

        // Slots 9-44 FREE for player items

        $menu->setListener(function (DeterministicInvMenuTransaction $t) use ($plugin): void {
            $player  = $t->getPlayer();
            $slot    = $t->getAction()->getSlot();
            $action  = $t->getItemClicked()->getNamedTag()->getString("es_action", "");

            // Top/bottom row pe click block karo
            if ($slot < 9 || $slot >= 45) {
                if ($action === "do_sell") {
                    self::processSell($player, $plugin, $t->getAction()->getInventory());
                } elseif ($action === "cancel") {
                    self::returnAllItems($player, $t->getAction()->getInventory());
                    $player->removeCurrentWindow();
                } else {
                    $t->discard();
                }
                return;
            }
            // Slots 9-44: player freely rakhe items
        });

        $menu->send($player);
    }

    // ── Sell Process ──────────────────────────────────────────────
    private static function processSell(Player $player, Main $plugin, \pocketmine\inventory\Inventory $inv): void {
        $shopItems   = $plugin->getShopItems();
        $totalEarned = 0.0;
        $soldCount   = 0;
        $invalid     = [];

        for ($slot = 9; $slot <= 44; $slot++) {
            $slotItem = $inv->getItem($slot);
            if ($slotItem->isNull()) continue;

            $found = false;
            foreach ($shopItems as $itemId => $data) {
                $sellPrice = (float) ($data["sell"] ?? 0);
                if ($sellPrice <= 0) continue;
                $test = StringToItemParser::getInstance()->parse($itemId);
                if ($test !== null && !$test->isNull() && $test->getTypeId() === $slotItem->getTypeId()) {
                    $totalEarned += $sellPrice * $slotItem->getCount();
                    $soldCount   += $slotItem->getCount();
                    $inv->setItem($slot, VanillaItems::AIR());
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $invalid[] = clone $slotItem;
                $inv->setItem($slot, VanillaItems::AIR());
            }
        }

        if ($soldCount > 0) {
            $plugin->addMoney($player->getName(), $totalEarned);
            $player->sendMessage($plugin->getMessage("sell-success", [
                "amount"  => $soldCount,
                "item"    => "items",
                "price"   => $plugin->formatMoney($totalEarned),
                "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
            ]));
        } else {
            $player->sendMessage($plugin->getMessage("sell-nothing"));
        }

        foreach ($invalid as $ri) {
            foreach ($player->getInventory()->addItem($ri) as $drop) {
                $player->getWorld()->dropItem($player->getPosition(), $drop);
            }
            $player->sendMessage($plugin->getMessage("sell-invalid", ["item" => $ri->getName()]));
        }

        $player->removeCurrentWindow();
    }

    private static function returnAllItems(Player $player, \pocketmine\inventory\Inventory $inv): void {
        for ($slot = 9; $slot <= 44; $slot++) {
            $item = $inv->getItem($slot);
            if ($item->isNull()) continue;
            foreach ($player->getInventory()->addItem($item) as $drop) {
                $player->getWorld()->dropItem($player->getPosition(), $drop);
            }
            $inv->setItem($slot, VanillaItems::AIR());
        }
    }
}
