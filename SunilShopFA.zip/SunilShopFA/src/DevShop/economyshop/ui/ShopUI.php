<?php

declare(strict_types=1);

namespace DevShop\economyshop\ui;

use DevShop\economyshop\Main;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopUI {

    // ── /SPShop - Main Categories ─────────────────────────────────
    public static function openMainShop(Player $player, Main $plugin): void {
        $categories = $plugin->getShopCategories();
        $bal        = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $catIds     = array_keys($categories);

        $form = new SimpleForm(function(Player $player, ?int $data) use($plugin, $catIds): void {
            if ($data === null) return;
            if (!isset($catIds[$data])) return;
            self::openCategory($player, $plugin, $catIds[$data]);
        });

        $form->setTitle("§6§l» EconomyShop «");
        $form->setContent("§eBalance: §a" . $bal . "\n§7Category choose karo:");

        foreach ($categories as $catId => $catData) {
            $name      = TF::colorize($catData["name"] ?? $catId);
            $itemCount = count($catData["items"] ?? []);
            $form->addButton($name . "\n§7" . $itemCount . " items", 0, "");
        }

        $player->sendForm($form);
    }

    // ── Category Items ────────────────────────────────────────────
    public static function openCategory(Player $player, Main $plugin, string $catId): void {
        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();
        $catData    = $categories[$catId] ?? null;

        if ($catData === null) {
            $player->sendMessage(TF::RED . "Category nahi mili!");
            return;
        }

        $catName = TF::colorize($catData["name"] ?? $catId);
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));

        $itemIds = [];

        $form = new SimpleForm(function(Player $player, ?int $data) use($plugin, $catId, &$itemIds): void {
            if ($data === null) return;
            if ($data === 0) {
                self::openMainShop($player, $plugin);
                return;
            }
            $idx    = $data - 1;
            $itemId = $itemIds[$idx] ?? null;
            if ($itemId !== null) {
                self::openBuyMenu($player, $plugin, $itemId, $catId);
            }
        });

        $form->setTitle("§6§l» " . strip_tags($catName) . " «");
        $form->setContent("§eBalance: §a" . $bal . "\n§7Item choose karo:");
        $form->addButton("§c§l« Wapas Jao\n§r§7Categories mein wapas", 0, "textures/ui/back_button_hover");

        foreach (($catData["items"] ?? []) as $itemId) {
            $itemData = $allItems[$itemId] ?? null;
            if ($itemData === null) continue;

            $buy  = (float) ($itemData["buy"]  ?? 0);
            $sell = (float) ($itemData["sell"] ?? 0);
            $name = $itemData["name"] ?? $itemId;

            $buyText  = $buy  > 0 ? "§aBuy: §f"  . $plugin->formatMoney($buy)  : "§cN/A";
            $sellText = $sell > 0 ? "§bSell: §f" . $plugin->formatMoney($sell) : "§cN/A";

            $form->addButton("§e§l" . $name . "\n" . $buyText . "  " . $sellText, 0, "");
            $itemIds[] = $itemId;
        }

        $player->sendForm($form);
    }

    // ── Buy Amount ────────────────────────────────────────────────
    public static function openBuyMenu(Player $player, Main $plugin, string $itemId, string $catId): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) return;

        $name     = $itemData["name"] ?? $itemId;
        $buy      = (float) ($itemData["buy"]  ?? 0);
        $sell     = (float) ($itemData["sell"] ?? 0);
        $bal      = $plugin->getMoney($player->getName());

        if ($buy <= 0) {
            $player->sendMessage(TF::RED . $name . " kharida nahi ja sakta!");
            self::openCategory($player, $plugin, $catId);
            return;
        }

        $form = new CustomForm(function(Player $player, ?array $data) use($plugin, $itemId, $catId, $name, $buy): void {
            if ($data === null) return;
            $amount = (int) ($data[1] ?? 1);
            if ($amount < 1) {
                $player->sendMessage(TF::RED . "Galat amount!");
                return;
            }
            self::processBuy($player, $plugin, $itemId, $amount, $catId);
        });

        $form->setTitle("§6§l" . $name);
        $form->addLabel(
            "§eBuy Price: §a" . $plugin->formatMoney($buy) . " / item\n" .
            "§bSell Price: §a" . ($sell > 0 ? $plugin->formatMoney($sell) : "N/A") . "\n" .
            "§eBalance: §a" . $plugin->formatMoney($bal)
        );
        $form->addSlider("§7Kitna kharidna hai?", 1, 64, 1, 1);

        $player->sendForm($form);
    }

    // ── Process Buy ───────────────────────────────────────────────
    public static function processBuy(Player $player, Main $plugin, string $itemId, int $amount, string $catId): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) {
            $player->sendMessage(TF::RED . "Item shop mein nahi hai!");
            return;
        }

        $buyPrice = (float) ($itemData["buy"] ?? 0);
        if ($buyPrice <= 0) {
            $player->sendMessage(TF::RED . "Ye item kharida nahi ja sakta!");
            return;
        }

        $total = $buyPrice * $amount;
        $bal   = $plugin->getMoney($player->getName());

        if ($bal < $total) {
            $player->sendMessage($plugin->getMessage("not-enough-money", [
                "balance" => $plugin->formatMoney($bal),
            ]));
            return;
        }

        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null || $item->isNull()) {
            $player->sendMessage(TF::RED . "Item error: " . $itemId);
            return;
        }

        $item->setCount($amount);

        if (!$player->getInventory()->canAddItem($item)) {
            $player->sendMessage($plugin->getMessage("inventory-full"));
            return;
        }

        $plugin->reduceMoney($player->getName(), $total);
        $player->getInventory()->addItem($item);

        $player->sendMessage($plugin->getMessage("buy-success", [
            "amount"  => $amount,
            "item"    => $itemData["name"] ?? $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── /SPSell Menu ──────────────────────────────────────────────
    public static function openSellMenu(Player $player, Main $plugin): void {
        $handItem = $player->getInventory()->getItemInHand();
        $bal      = $plugin->formatMoney($plugin->getMoney($player->getName()));

        $content = "§eBalance: §a" . $bal . "\n\n";

        if (!$handItem->isNull()) {
            $sellPrice = self::getSellPrice($handItem, $plugin);
            if ($sellPrice !== null) {
                $total    = $sellPrice * $handItem->getCount();
                $content .= "§7Haath mein: §e" . $handItem->getName() . " §7x" . $handItem->getCount() . "\n";
                $content .= "§bSell Value: §a" . $plugin->formatMoney($total) . "\n";
            } else {
                $content .= "§7Haath mein: §e" . $handItem->getName() . " §c(Nahi bikta)\n";
            }
        } else {
            $content .= "§7Haath mein kuch nahi hai\n";
        }

        $content .= "\n§7Kya bechna chahte ho?";

        $form = new SimpleForm(function(Player $player, ?int $data) use($plugin): void {
            if ($data === null) return;
            match ($data) {
                0 => self::sellHand($player, $plugin),
                1 => self::sellAll($player, $plugin),
                default => null,
            };
        });

        $form->setTitle("§b§l» SP Sell «");
        $form->setContent($content);
        $form->addButton("§a§lSell Hand\n§r§7Haath wala item becho",   0, "textures/items/diamond");
        $form->addButton("§6§lSell All\n§r§7Sab sellable items becho", 0, "textures/items/gold_ingot");
        $form->addButton("§c§lCancel\n§r§7Band karo",                  0, "textures/ui/cancel");

        $player->sendForm($form);
    }

    // ── Sell Hand ─────────────────────────────────────────────────
    public static function sellHand(Player $player, Main $plugin): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage(TF::RED . "Haath mein kuch nahi hai!");
            return;
        }
        $sellPrice = self::getSellPrice($item, $plugin);
        if ($sellPrice === null) {
            $player->sendMessage($plugin->getMessage("sell-invalid", ["item" => $item->getName()]));
            return;
        }
        $amount = $item->getCount();
        $total  = $sellPrice * $amount;
        $player->getInventory()->removeItem($item);
        $plugin->addMoney($player->getName(), $total);
        $player->sendMessage($plugin->getMessage("sell-success", [
            "amount"  => $amount,
            "item"    => $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── Sell All ──────────────────────────────────────────────────
    public static function sellAll(Player $player, Main $plugin): void {
        $inventory   = $player->getInventory();
        $totalEarned = 0.0;
        $soldCount   = 0;
        $toRemove    = [];

        foreach ($inventory->getContents() as $item) {
            if ($item->isNull()) continue;
            $sellPrice = self::getSellPrice($item, $plugin);
            if ($sellPrice !== null) {
                $totalEarned += $sellPrice * $item->getCount();
                $soldCount   += $item->getCount();
                $toRemove[]   = clone $item;
            }
        }

        if ($soldCount === 0) {
            $player->sendMessage($plugin->getMessage("sell-nothing"));
            return;
        }

        foreach ($toRemove as $item) {
            $inventory->removeItem($item);
        }

        $plugin->addMoney($player->getName(), $totalEarned);
        $player->sendMessage($plugin->getMessage("sell-all-success", [
            "amount"  => $soldCount,
            "price"   => $plugin->formatMoney($totalEarned),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ── Sell Price Helper ─────────────────────────────────────────
    public static function getSellPrice(\pocketmine\item\Item $item, Main $plugin): ?float {
        foreach ($plugin->getShopItems() as $itemId => $data) {
            $sellPrice = (float) ($data["sell"] ?? 0);
            if ($sellPrice <= 0) continue;
            $test = StringToItemParser::getInstance()->parse($itemId);
            if ($test !== null && !$test->isNull() && $test->getTypeId() === $item->getTypeId()) {
                return $sellPrice;
            }
        }
        return null;
    }
}
