<?php
declare(strict_types=1);
namespace DevShop\economyshop\listener;
use DevShop\economyshop\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat as TF;
class EventListener implements Listener {
    public function __construct(private Main $plugin) {}
    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $bal    = $this->plugin->formatMoney($this->plugin->getMoney($player->getName()));
        $player->sendMessage(
            TF::GOLD . "━━━━━━━━━━━━━━━━━━━━━\n" .
            TF::YELLOW . " Welcome " . TF::WHITE . $player->getName() . TF::YELLOW . "!\n" .
            TF::YELLOW . " Balance: " . TF::GREEN . $bal . "\n" .
            TF::GRAY . " /SPShop  /SPSell  /SPMoney\n" .
            TF::GOLD . "━━━━━━━━━━━━━━━━━━━━━"
        );
    }
}
