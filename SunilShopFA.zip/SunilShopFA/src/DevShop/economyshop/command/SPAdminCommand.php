<?php
declare(strict_types=1);
namespace DevShop\economyshop\command;
use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;
class SPAdminCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("spadmin", "Shop admin", "/SPAdmin", ["SPAdmin"]);
        $this->setPermission("economyshop.admin");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return true;
        $sub = strtolower($args[0] ?? "help");
        switch ($sub) {
            case "additem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game!"); return true; }
                if (count($args) < 4) { $sender->sendMessage(TF::RED . "Usage: /SPAdmin additem <cat> <buy> <sell> (haath mein item rakho)"); return true; }
                $cats = $this->plugin->getShopCategories();
                if (!isset($cats[$args[1]])) { $sender->sendMessage(TF::RED . "Cat nahi mili! Available: " . implode(", ", array_keys($cats))); return true; }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) { $sender->sendMessage(TF::RED . "Haath mein item rakho!"); return true; }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                $this->plugin->addItemToShop($args[1], $itemId, $item->getName(), (float)$args[2], (float)$args[3]);
                $sender->sendMessage(TF::GREEN . "Added: " . $item->getName() . " | Buy: " . $this->plugin->formatMoney((float)$args[2]) . " Sell: " . $this->plugin->formatMoney((float)$args[3]));
                break;
            case "removeitem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game!"); return true; }
                if (count($args) < 2) { $sender->sendMessage(TF::RED . "Usage: /SPAdmin removeitem <cat>"); return true; }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) { $sender->sendMessage(TF::RED . "Haath mein item rakho!"); return true; }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                if ($this->plugin->removeItemFromShop($args[1], $itemId)) {
                    $sender->sendMessage(TF::GREEN . "Removed: " . $item->getName());
                } else {
                    $sender->sendMessage(TF::RED . "Item nahi mila!");
                }
                break;
            case "givemoney":
                if (count($args) < 3) { $sender->sendMessage(TF::RED . "Usage: /SPAdmin givemoney <player> <amount>"); return true; }
                $this->plugin->addMoney($args[1], (float)$args[2]);
                $sender->sendMessage(TF::GREEN . "Diya " . $this->plugin->formatMoney((float)$args[2]) . " ko " . $args[1]);
                break;
            case "setmoney":
                if (count($args) < 3) { $sender->sendMessage(TF::RED . "Usage: /SPAdmin setmoney <player> <amount>"); return true; }
                \onebone\economyapi\EconomyAPI::getInstance()->setMoney($args[1], (float)$args[2]);
                $sender->sendMessage(TF::GREEN . $args[1] . " ka balance set hua: " . $this->plugin->formatMoney((float)$args[2]));
                break;
            case "reload":
                $this->plugin->reloadShop();
                $sender->sendMessage(TF::GREEN . "Shop reload ho gaya!");
                break;
            default:
                $sender->sendMessage(
                    TF::GOLD . "=== SPAdmin Help ===" . "\n" .
                    TF::YELLOW . "/SPAdmin additem <cat> <buy> <sell>\n" .
                    TF::YELLOW . "/SPAdmin removeitem <cat>\n" .
                    TF::YELLOW . "/SPAdmin givemoney <player> <amount>\n" .
                    TF::YELLOW . "/SPAdmin setmoney <player> <amount>\n" .
                    TF::YELLOW . "/SPAdmin reload\n" .
                    TF::AQUA . "Cats: " . implode(", ", array_keys($this->plugin->getShopCategories()))
                );
        }
        return true;
    }
}
