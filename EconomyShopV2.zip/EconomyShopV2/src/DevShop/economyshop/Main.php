<?php

declare(strict_types=1);

namespace DevShop\economyshop;

use DevShop\economyshop\command\ShopCommand;
use DevShop\economyshop\command\SellCommand;
use DevShop\economyshop\command\MoneyCommand;
use DevShop\economyshop\command\PayCommand;
use DevShop\economyshop\command\ShopAdminCommand;
use DevShop\economyshop\listener\EventListener;
use DevShop\economyshop\libs\muqsit\invmenu\InvMenuHandler;
use onebone\economyapi\EconomyAPI;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase {

    private static Main $instance;
    private Config $shopConfig;
    private Config $msgConfig;

    public static function getInstance(): Main {
        return self::$instance;
    }

    protected function onEnable(): void {
        self::$instance = $this;

        // Register InvMenu
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        // Save default resources
        $this->saveResource("shop.yml");
        $this->saveResource("messages.yml");
        $this->saveDefaultConfig();

        $this->shopConfig = new Config($this->getDataFolder() . "shop.yml", Config::YAML);
        $this->msgConfig  = new Config($this->getDataFolder() . "messages.yml", Config::YAML);

        // Register commands
        $map = $this->getServer()->getCommandMap();
        $map->register("economyshop", new ShopCommand($this));
        $map->register("economyshop", new SellCommand($this));
        $map->register("economyshop", new MoneyCommand($this));
        $map->register("economyshop", new PayCommand($this));
        $map->register("economyshop", new ShopAdminCommand($this));

        // Register events
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        $this->getLogger()->info(TF::GREEN . "EconomyShop v2.0.0 enabled! /shop /sell /money ready!");
    }

    // ─── Shop Data ────────────────────────────────────────────────

    public function getShopItems(): array {
        return $this->shopConfig->get("items", []);
    }

    public function getShopCategories(): array {
        return $this->shopConfig->get("categories", []);
    }

    public function getItemData(string $itemId): ?array {
        $items = $this->getShopItems();
        return $items[$itemId] ?? null;
    }

    public function addItemToShop(string $catId, string $itemId, string $name, float $buy, float $sell): void {
        $data = $this->shopConfig->getAll();
        $data["items"][$itemId] = ["name" => $name, "buy" => $buy, "sell" => $sell];
        if (!isset($data["categories"][$catId]["items"])) {
            $data["categories"][$catId]["items"] = [];
        }
        if (!in_array($itemId, $data["categories"][$catId]["items"])) {
            $data["categories"][$catId]["items"][] = $itemId;
        }
        $this->shopConfig->setAll($data);
        $this->shopConfig->save();
    }

    public function removeItemFromShop(string $catId, string $itemId): bool {
        $data = $this->shopConfig->getAll();
        if (!isset($data["items"][$itemId])) return false;
        unset($data["items"][$itemId]);
        $data["categories"][$catId]["items"] = array_values(
            array_filter($data["categories"][$catId]["items"] ?? [], fn($i) => $i !== $itemId)
        );
        $this->shopConfig->setAll($data);
        $this->shopConfig->save();
        return true;
    }

    public function reloadShop(): void {
        $this->shopConfig = new Config($this->getDataFolder() . "shop.yml", Config::YAML);
    }

    // ─── Messages ─────────────────────────────────────────────────

    public function getMessage(string $key, array $replace = []): string {
        $msg = $this->msgConfig->get($key, "&cMessage not found: $key");
        foreach ($replace as $k => $v) {
            $msg = str_replace("{" . $k . "}", (string)$v, $msg);
        }
        return TF::colorize($msg);
    }

    // ─── EconomyAPI ───────────────────────────────────────────────

    public function getMoney(string $player): float {
        $eco = EconomyAPI::getInstance();
        $bal = $eco->myMoney($player);
        return ($bal === false) ? 0.0 : (float)$bal;
    }

    public function addMoney(string $player, float $amount): bool {
        return EconomyAPI::getInstance()->addMoney($player, $amount) === EconomyAPI::RET_SUCCESS;
    }

    public function reduceMoney(string $player, float $amount): bool {
        return EconomyAPI::getInstance()->reduceMoney($player, $amount) === EconomyAPI::RET_SUCCESS;
    }

    public function formatMoney(float $amount): string {
        $symbol = EconomyAPI::getInstance()->getMonetaryUnit();
        return $symbol . number_format($amount, 2);
    }
}
