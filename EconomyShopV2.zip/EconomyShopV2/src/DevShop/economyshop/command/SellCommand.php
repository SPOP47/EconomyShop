<?php

declare(strict_types=1);

namespace DevShop\economyshop\command;

use DevShop\economyshop\Main;
use DevShop\economyshop\ui\ShopUI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class SellCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct("sell", "Sell chest kholo", "/sell", []);
        $this->setPermission("economyshop.sell");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TF::RED . "Sirf in-game chalao!");
            return true;
        }
        if (!$this->testPermission($sender)) return true;
        ShopUI::openSellMenu($sender, $this->plugin);
        return true;
    }
}
