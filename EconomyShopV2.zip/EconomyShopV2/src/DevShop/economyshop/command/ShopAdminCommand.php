<?php

declare(strict_types=1);

namespace DevShop\economyshop\command;

use DevShop\economyshop\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopAdminCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct("shopadmin", "Shop admin", "/shopadmin", ["sa"]);
        $this->setPermission("economyshop.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return true;

        $sub = strtolower($args[0] ?? "help");

        switch ($sub) {
            case "additem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game use karo!"); return true; }
                if (count($args) < 4) {
                    $sender->sendMessage(TF::RED . "Usage: /sa additem <category> <buy_price> <sell_price>");
                    $sender->sendMessage(TF::GRAY . "(Haath mein woh item rakho jo add karna hai)");
                    return true;
                }
                $catId     = $args[1];
                $buyPrice  = (float)$args[2];
                $sellPrice = (float)$args[3];
                $cats = $this->plugin->getShopCategories();
                if (!isset($cats[$catId])) {
                    $sender->sendMessage(TF::RED . "Category \"$catId\" nahi mili!");
                    $sender->sendMessage(TF::YELLOW . "Available: " . implode(", ", array_keys($cats)));
                    return true;
                }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Pehle haath mein item rakho!");
                    return true;
                }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                $this->plugin->addItemToShop($catId, $itemId, $item->getName(), $buyPrice, $sellPrice);
                $sender->sendMessage(TF::GREEN . "Added: " . $item->getName() . " → " . $catId .
                    " | Buy: " . $this->plugin->formatMoney($buyPrice) .
                    " | Sell: " . $this->plugin->formatMoney($sellPrice));
                break;

            case "removeitem":
                if (!$sender instanceof Player) { $sender->sendMessage(TF::RED . "In-game use karo!"); return true; }
                if (count($args) < 2) {
                    $sender->sendMessage(TF::RED . "Usage: /sa removeitem <category>");
                    $sender->sendMessage(TF::GRAY . "(Haath mein woh item rakho jo remove karna hai)");
                    return true;
                }
                $catId = $args[1];
                $item  = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage(TF::RED . "Pehle haath mein item rakho!");
                    return true;
                }
                $itemId = strtolower(str_replace(" ", "_", $item->getName()));
                if ($this->plugin->removeItemFromShop($catId, $itemId)) {
                    $sender->sendMessage(TF::GREEN . "Removed: " . $item->getName() . " from " . $catId);
                } else {
                    $sender->sendMessage(TF::RED . "Item nahi mila category mein!");
                }
                break;

            case "reload":
                $this->plugin->reloadShop();
                $sender->sendMessage(TF::GREEN . "Shop reload ho gaya!");
                break;

            default:
                $sender->sendMessage(
                    TF::GOLD . TF::BOLD . "=== ShopAdmin Help ===" . TF::RESET . "\n" .
                    TF::YELLOW . "/sa additem <cat> <buy> <sell>" . TF::GRAY . " - Item add karo\n" .
                    TF::YELLOW . "/sa removeitem <cat>" . TF::GRAY . " - Item remove karo\n" .
                    TF::YELLOW . "/sa reload" . TF::GRAY . " - Config reload\n" .
                    TF::AQUA . "Categories: " . TF::WHITE . implode(", ", array_keys($this->plugin->getShopCategories()))
                );
                break;
        }

        return true;
    }
}
