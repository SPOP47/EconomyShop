<?php

declare(strict_types=1);

namespace DevShop\economyshop\ui;

use DevShop\economyshop\Main;
use DevShop\economyshop\libs\muqsit\invmenu\InvMenu;
use DevShop\economyshop\libs\muqsit\invmenu\type\InvMenuTypeIds;
use DevShop\economyshop\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class ShopUI {

    // ─── Helper: Glass Border Item ────────────────────────────────
    private static function glass(): Item {
        $g = VanillaBlocks::GRAY_STAINED_GLASS_PANE()->asItem();
        $g->setCustomName(TF::RESET . " ");
        return $g;
    }

    // ─── Helper: Fill border slots of 54-slot inventory ───────────
    private static function fillBorder(InvMenu $menu): void {
        $inv = $menu->getInventory();
        // Top row: 0-8, Bottom row: 45-53
        // Left col: 9,18,27,36 - Right col: 17,26,35,44
        $border = array_merge(
            range(0, 8),
            range(45, 53),
            [9, 18, 27, 36, 17, 26, 35, 44]
        );
        foreach ($border as $slot) {
            $inv->setItem($slot, self::glass());
        }
    }

    // ─── /shop - Category List ────────────────────────────────────
    public static function openMainShop(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::GOLD . TF::BOLD . "» EconomyShop «");
        self::fillBorder($menu);

        $inv        = $menu->getInventory();
        $categories = $plugin->getShopCategories();

        // Inner slots (not border): 10-16, 19-25, 28-34, 37-43
        $slots = [10,11,12,13,14,15,16,
                  19,20,21,22,23,24,25,
                  28,29,30,31,32,33,34,
                  37,38,39,40,41,42,43];
        $i = 0;

        foreach ($categories as $catId => $catData) {
            if ($i >= count($slots)) break;

            // Category icon item
            $iconName = $catData["icon"] ?? "chest";
            $icon = StringToItemParser::getInstance()->parse($iconName);
            if ($icon === null || $icon->isNull()) {
                $icon = VanillaBlocks::CHEST()->asItem();
            }

            $catDisplayName = TF::colorize($catData["name"] ?? $catId);
            $itemCount      = count($catData["items"] ?? []);

            $icon->setCustomName($catDisplayName);
            $icon->setLore([
                TF::GRAY . $itemCount . " items available",
                "",
                TF::YELLOW . "Click karo browse karne ke liye!",
            ]);

            // Tag this item with category id
            $nbt = $icon->getNamedTag();
            $nbt->setString("es_cat", $catId);
            $icon->setNamedTag($nbt);

            $inv->setItem($slots[$i], $icon);
            $i++;
        }

        // Balance display at slot 49
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Tumhara Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $inv->setItem(49, $balItem);

        $menu->setListener(InvMenu::readonly(
            function(DeterministicInvMenuTransaction $transaction) use($plugin): void {
                $player = $transaction->getPlayer();
                $item   = $transaction->getItemClicked();
                $catId  = $item->getNamedTag()->getString("es_cat", "");

                if ($catId !== "") {
                    $player->removeCurrentWindow();
                    $transaction->then(
                        function(Player $p) use($plugin, $catId): void {
                            self::openCategoryItems($p, $plugin, $catId);
                        }
                    );
                }
            }
        ));

        $menu->send($player);
    }

    // ─── /shop - Items in a Category ─────────────────────────────
    public static function openCategoryItems(Player $player, Main $plugin, string $catId): void {
        $categories = $plugin->getShopCategories();
        $allItems   = $plugin->getShopItems();
        $catData    = $categories[$catId] ?? null;

        if ($catData === null) {
            $player->sendMessage(TF::RED . "Category nahi mili!");
            return;
        }

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $catDisplayName = TF::colorize($catData["name"] ?? $catId);
        $menu->setName(TF::GOLD . TF::BOLD . "» " . TF::colorize($catData["name"] ?? $catId) . " «");
        self::fillBorder($menu);

        $inv = $menu->getInventory();

        // Back button slot 45
        $back = VanillaBlocks::OAK_STAIRS()->asItem();
        $back->setCustomName(TF::RED . TF::BOLD . "« Wapas Jao");
        $back->setLore([TF::GRAY . "Categories mein wapas"]);
        $nbtBack = $back->getNamedTag();
        $nbtBack->setString("es_action", "back");
        $back->setNamedTag($nbtBack);
        $inv->setItem(45, $back);

        // Balance slot 49
        $bal     = $plugin->formatMoney($plugin->getMoney($player->getName()));
        $balItem = VanillaBlocks::GOLD_BLOCK()->asItem();
        $balItem->setCustomName(TF::YELLOW . TF::BOLD . "Tumhara Balance");
        $balItem->setLore([TF::GREEN . $bal]);
        $inv->setItem(49, $balItem);

        // Items in inner slots
        $slots = [10,11,12,13,14,15,16,
                  19,20,21,22,23,24,25,
                  28,29,30,31,32,33,34,
                  37,38,39,40,41,42,43];
        $i = 0;

        foreach (($catData["items"] ?? []) as $itemId) {
            if ($i >= count($slots)) break;

            $itemData = $allItems[$itemId] ?? null;
            if ($itemData === null) continue;

            $item = StringToItemParser::getInstance()->parse($itemId);
            if ($item === null || $item->isNull()) continue;

            $buyPrice  = (float)($itemData["buy"]  ?? 0);
            $sellPrice = (float)($itemData["sell"] ?? 0);
            $dispName  = $itemData["name"] ?? $item->getName();

            $item->setCustomName(TF::YELLOW . TF::BOLD . $dispName);
            $item->setLore([
                TF::GREEN . "Buy:  " . TF::WHITE . ($buyPrice  > 0 ? $plugin->formatMoney($buyPrice)  : TF::RED . "Nahi milta"),
                TF::AQUA  . "Sell: " . TF::WHITE . ($sellPrice > 0 ? $plugin->formatMoney($sellPrice) : TF::RED . "Nahi bikta"),
                "",
                TF::YELLOW . "Click » Buy x1",
            ]);

            $nbt = $item->getNamedTag();
            $nbt->setString("es_action", "buy");
            $nbt->setString("es_item", $itemId);
            $item->setNamedTag($nbt);

            $inv->setItem($slots[$i], $item);
            $i++;
        }

        $menu->setListener(InvMenu::readonly(
            function(DeterministicInvMenuTransaction $transaction) use($plugin, $catId): void {
                $player = $transaction->getPlayer();
                $item   = $transaction->getItemClicked();
                $nbt    = $item->getNamedTag();
                $action = $nbt->getString("es_action", "");

                if ($action === "back") {
                    $player->removeCurrentWindow();
                    $transaction->then(
                        function(Player $p) use($plugin): void {
                            self::openMainShop($p, $plugin);
                        }
                    );
                    return;
                }

                if ($action === "buy") {
                    $itemId = $nbt->getString("es_item", "");
                    if ($itemId !== "") {
                        self::processBuy($player, $plugin, $itemId, 1);
                    }
                }
            }
        ));

        $menu->send($player);
    }

    // ─── Process Buy Logic ────────────────────────────────────────
    public static function processBuy(Player $player, Main $plugin, string $itemId, int $amount): void {
        $itemData = $plugin->getItemData($itemId);
        if ($itemData === null) {
            $player->sendMessage(TF::RED . "Item shop mein nahi hai!");
            return;
        }

        $buyPrice = (float)($itemData["buy"] ?? 0);
        if ($buyPrice <= 0) {
            $player->sendMessage(TF::RED . "Ye item kharida nahi ja sakta!");
            return;
        }

        $total = $buyPrice * $amount;
        $bal   = $plugin->getMoney($player->getName());

        if ($bal < $total) {
            $player->sendMessage($plugin->getMessage("not-enough-money", [
                "balance" => $plugin->formatMoney($bal),
            ]));
            return;
        }

        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null || $item->isNull()) {
            $player->sendMessage(TF::RED . "Item parse nahi hua: " . $itemId);
            return;
        }

        $item->setCount($amount);

        if (!$player->getInventory()->canAddItem($item)) {
            $player->sendMessage($plugin->getMessage("inventory-full"));
            return;
        }

        $plugin->reduceMoney($player->getName(), $total);
        $player->getInventory()->addItem($item);

        $player->sendMessage($plugin->getMessage("buy-success", [
            "amount"  => $amount,
            "item"    => $itemData["name"] ?? $item->getName(),
            "price"   => $plugin->formatMoney($total),
            "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
        ]));
    }

    // ─── /sell - Sell Chest GUI ───────────────────────────────────
    public static function openSellMenu(Player $player, Main $plugin): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TF::AQUA . TF::BOLD . "» Items Becho «");

        $inv = $menu->getInventory();

        // Top row glass (0-8)
        for ($s = 0; $s <= 8; $s++) {
            $inv->setItem($s, self::glass());
        }

        // Bottom row glass (45-53)
        for ($s = 45; $s <= 53; $s++) {
            $inv->setItem($s, self::glass());
        }

        // Info item at slot 4 (top middle)
        $info = VanillaBlocks::EMERALD_ORE()->asItem();
        $info->setCustomName(TF::GREEN . TF::BOLD . "SELL CHEST");
        $info->setLore([
            TF::GRAY . "Neeche items rakh do!",
            TF::YELLOW . "SELL dabao to valid items bik jayenge",
            TF::RED . "Invalid items wapis mil jayenge",
        ]);
        $inv->setItem(4, $info);

        // SELL ALL button at slot 49
        $sellBtn = VanillaBlocks::EMERALD_BLOCK()->asItem();
        $sellBtn->setCustomName(TF::GREEN . TF::BOLD . "» SELL ALL «");
        $sellBtn->setLore([TF::GRAY . "Sab valid items becho!"]);
        $nbtS = $sellBtn->getNamedTag();
        $nbtS->setString("es_action", "do_sell");
        $sellBtn->setNamedTag($nbtS);
        $inv->setItem(49, $sellBtn);

        // Cancel button at slot 45 and 53
        $cancelBtn = VanillaBlocks::REDSTONE_BLOCK()->asItem();
        $cancelBtn->setCustomName(TF::RED . TF::BOLD . "» CANCEL «");
        $cancelBtn->setLore([TF::GRAY . "Items wapis lo aur band karo"]);
        $nbtC = $cancelBtn->getNamedTag();
        $nbtC->setString("es_action", "cancel");
        $cancelBtn->setNamedTag($nbtC);
        $inv->setItem(45, $cancelBtn);
        $inv->setItem(53, $cancelBtn);

        // Slots 9-44 are FREE for player to place items
        // (middle area - no glass, no items)

        $menu->setListener(
            function(DeterministicInvMenuTransaction $transaction) use($plugin): void {
                $player  = $transaction->getPlayer();
                $item    = $transaction->getItemClicked();
                $slot    = $transaction->getAction()->getSlot();
                $action  = $item->getNamedTag()->getString("es_action", "");

                // Block top/bottom row except sell slots 9-44
                if ($slot < 9 || $slot > 44) {
                    // Only allow clicking sell/cancel buttons
                    if ($action === "do_sell") {
                        self::processSell($player, $plugin, $transaction->getAction()->getInventory());
                        return;
                    }
                    if ($action === "cancel") {
                        self::returnItems($player, $transaction->getAction()->getInventory());
                        $player->removeCurrentWindow();
                        return;
                    }
                    // Block all other clicks on border/buttons
                    $transaction->discard();
                    return;
                }
                // Slots 9-44: player can freely add/remove items - allow
            }
        );

        $menu->send($player);
    }

    // ─── Process Sell ─────────────────────────────────────────────
    private static function processSell(Player $player, Main $plugin, \pocketmine\inventory\Inventory $inv): void {
        $shopItems   = $plugin->getShopItems();
        $totalEarned = 0.0;
        $soldCount   = 0;
        $invalidItems = [];

        for ($slot = 9; $slot <= 44; $slot++) {
            $slotItem = $inv->getItem($slot);
            if ($slotItem->isNull()) continue;

            $found = false;
            foreach ($shopItems as $itemId => $data) {
                $sellPrice = (float)($data["sell"] ?? 0);
                if ($sellPrice <= 0) continue;

                $testItem = StringToItemParser::getInstance()->parse($itemId);
                if ($testItem !== null && !$testItem->isNull() && $testItem->getTypeId() === $slotItem->getTypeId()) {
                    $totalEarned += $sellPrice * $slotItem->getCount();
                    $soldCount   += $slotItem->getCount();
                    $inv->setItem($slot, VanillaItems::AIR());
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $invalidItems[] = clone $slotItem;
                $inv->setItem($slot, VanillaItems::AIR());
            }
        }

        // Give earned money
        if ($soldCount > 0) {
            $plugin->addMoney($player->getName(), $totalEarned);
            $player->sendMessage($plugin->getMessage("sell-success", [
                "amount"  => $soldCount,
                "item"    => "items",
                "price"   => $plugin->formatMoney($totalEarned),
                "balance" => $plugin->formatMoney($plugin->getMoney($player->getName())),
            ]));
        } else {
            $player->sendMessage($plugin->getMessage("sell-nothing"));
        }

        // Return invalid items
        foreach ($invalidItems as $ri) {
            $leftover = $player->getInventory()->addItem($ri);
            foreach ($leftover as $drop) {
                $player->getWorld()->dropItem($player->getPosition(), $drop);
            }
            $player->sendMessage($plugin->getMessage("sell-invalid", ["item" => $ri->getName()]));
        }

        $player->removeCurrentWindow();
    }

    // ─── Return all items to player (cancel) ─────────────────────
    private static function returnItems(Player $player, \pocketmine\inventory\Inventory $inv): void {
        for ($slot = 9; $slot <= 44; $slot++) {
            $slotItem = $inv->getItem($slot);
            if ($slotItem->isNull()) continue;
            $leftover = $player->getInventory()->addItem($slotItem);
            foreach ($leftover as $drop) {
                $player->getWorld()->dropItem($player->getPosition(), $drop);
            }
            $inv->setItem($slot, VanillaItems::AIR());
        }
        $player->sendMessage(TF::YELLOW . "Items wapis de diye!");
    }
}
