<?php

declare(strict_types=1);

namespace DevShop\economyshop\libs\muqsit\invmenu\type\util\builder;

use DevShop\economyshop\libs\muqsit\invmenu\type\InvMenuType;

interface InvMenuTypeBuilder{

	public function build() : InvMenuType;
}