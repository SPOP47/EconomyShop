<?php

declare(strict_types=1);

namespace DevShop\economyshop\libs\muqsit\invmenu\session;

use DevShop\economyshop\libs\muqsit\invmenu\InvMenu;
use DevShop\economyshop\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;

final class InvMenuInfo{

	public function __construct(
		readonly public InvMenu $menu,
		readonly public InvMenuGraphic $graphic,
		readonly public ?string $graphic_name
	){}
}