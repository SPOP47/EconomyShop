<?php

declare(strict_types=1);

namespace DevShop\economyshop\libs\muqsit\invmenu\type;

use DevShop\economyshop\libs\muqsit\invmenu\InvMenu;
use DevShop\economyshop\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

interface InvMenuType{

	public function createGraphic(InvMenu $menu, Player $player) : ?InvMenuGraphic;

	public function createInventory() : Inventory;
}