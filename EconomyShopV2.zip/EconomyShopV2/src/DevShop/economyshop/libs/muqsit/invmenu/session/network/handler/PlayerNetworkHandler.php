<?php

declare(strict_types=1);

namespace DevShop\economyshop\libs\muqsit\invmenu\session\network\handler;

use Closure;
use DevShop\economyshop\libs\muqsit\invmenu\session\network\NetworkStackLatencyEntry;

interface PlayerNetworkHandler{

	public function createNetworkStackLatencyEntry(Closure $then) : NetworkStackLatencyEntry;
}