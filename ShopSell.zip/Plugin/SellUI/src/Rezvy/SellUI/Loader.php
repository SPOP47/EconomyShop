<?php
declare(strict_types=1);

namespace Rezvy\SellUI;

use pocketmine\Server;
use pocketmine\player\Player;

use pocketmine\plugin\PluginBase;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;

use jojoe77777\FormAPI\SimpleForm;

class Loader extends PluginBase implements Listener{
    
    public function onEnable() : void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
        @mkdir($this->getDataFolder());
       $this->saveDefaultConfig();
       $this->getResource("config.yml");
       
    }

    public function onCommand(CommandSender $sender, Command $cmd, String $label, Array $args) : bool {
        
        if($cmd->getName() == "sellui"){
            $this->SellUI($sender);
        }
        
        return true;
    }
    
    public function SellUI($player){
        $form = new SimpleForm(function(Player $player, int $data = null){
            if($data === null){
                return true;
            }
            
            switch($data){
                case 0:
                    $this->getServer()->dispatchCommand($player, "sell hand");
                break;
                
                case 1:
                    $this->getServer()->dispatchCommand($player, "sell all");
                break;
                
                case 2:
                    $this->getServer()->dispatchCommand($player, "sell ores");
                break;
                
                case 3:
                    $this->getserver()->dispatchCommand($player, "sell inv");
                break;
                
                case 4:
                    $player->sendMessage($this->getConfig()->get("exit-message"));
                break;
            }
        });
        $form->setTitle($this->getConfig()->get("sellui-title"));
        $form->addButton($this->getConfig()->get("button-sellhand"));
        $form->addButton($this->getConfig()->get("button-sellall"));
        $form->addButton($this->getConfig()->get("button-sellores"));
        $form->addButton($this->getConfig()->get("button-sellinv"));
        $form->addButton($this->getConfig()->get("button-exit"));
        $form->sendToPlayer($player);
        return $form;
    }
}